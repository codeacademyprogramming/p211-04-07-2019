﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[,,] dormitory = new string[2, 3, 2];

            #region Manual multidimensional array filling
            //dormitory[0, 0, 0] = "A";
            //dormitory[0, 0, 1] = "B";

            //dormitory[0, 1, 0] = "C";
            //dormitory[0, 1, 1] = "D";

            //dormitory[0, 2, 0] = "E";
            //dormitory[0, 2, 1] = "F";

            //dormitory[1, 0, 0] = "G";
            //dormitory[1, 0, 1] = "H";

            //dormitory[1, 1, 0] = "I";
            //dormitory[1, 1, 1] = "J";

            //dormitory[1, 2, 0] = "K";
            //dormitory[1, 2, 1] = "L";

            //Console.WriteLine(dormitory[1,2,1]);
            #endregion

            #region Automatic multidimensional array filling
            //for (int korpus = 0; korpus < dormitory.GetLength(0); korpus++)
            //{
            //    for (int mertebe = 0; mertebe < dormitory.GetLength(1); mertebe++)
            //    {
            //        for (int otaq = 0; otaq < dormitory.GetLength(2); otaq++)
            //        {
            //            Console.Write($"Who will stay at corpus {korpus+1} floor {mertebe+1} room {otaq+1}? ");
            //            string username = Console.ReadLine();

            //            dormitory[korpus, mertebe, otaq] = username;
            //        }
            //    }
            //}

            //Console.WriteLine(dormitory);


            //for(int i = 0; i < dormitory.Length; i++)
            //{
            //    Console.WriteLine(dormitory[i]);
            //}
            #endregion

            #region OOP, Class

            #region Polymorphism
            //Man Samir = new Man();
            //Samir.Firstname = "Samir";
            //Samir.Lastname = "Dadash-zade";
            //Samir.Birthdate = new DateTime(1991, 11, 20);

            //Man Aqil = new Man();
            //Aqil.Firstname = "Aqil";
            //Aqil.Lastname = "Atakishi";
            //Aqil.Birthdate = new DateTime(1999, 10, 10);

            //Woman flower = new Woman();
            //flower.Firstname = "Flower";
            //flower.Lastname = "Montenegro";
            //flower.Birthdate = new DateTime(2001, 01, 01);

            //Samir.Run();

            //Snake snake = new Snake();
            //snake.Name = "Tsssssss";
            //snake.Crawl();
            //snake.Sting();

            //Reptiles reptile = snake;
            //reptile.Crawl();

            //Animal animal = snake;
            //Console.WriteLine(animal.Name);

            //object o = snake;
            #endregion

            Employee employee = new Employee();
            employee.SetEmail("abc");

            Console.WriteLine(employee.GetEmail());

            #endregion
        }
    }

    abstract class Person
    {
        public string Firstname;
        public string Lastname;
        public DateTime Birthdate;

        public void Run()
        {
            Console.WriteLine("I am running");
        }
    }

    class Man : Person
    {
        public int BeardLength;
    }

    class Woman : Person
    {
        public int HairLength;
    }

    class Employee : Person
    {
        private string _email;


        // samir113 - ?_asb12@#4sdfk_??@sdkjfh
        //samir1234 - ?_sdfsd
        public void SetEmail(string email)
        {
            if(email.IndexOf("@") == -1)
            {
                throw new ArgumentException("Email is not valid.");
            }
            else
            {
                _email = email;
            }
        }

        public string GetEmail()
        {
            return _email;
        }

    }

    //super class/ base class/ parent class
    abstract class Animal
    {
        public string Name;
    }

    //sub class/ derived class/ child class
    abstract class Reptiles : Animal
    {
        public void Crawl (){
            Console.WriteLine("Crawling back to you");
        }
    }

    class Snake : Reptiles
    {
        public void Sting()
        {
            Console.WriteLine("I just stinged you");
        }
    }

}
